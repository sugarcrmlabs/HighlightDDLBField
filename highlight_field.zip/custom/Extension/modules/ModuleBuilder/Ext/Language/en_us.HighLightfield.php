<?php
$mod_strings['fieldTypes']['HighLightfield'] = 'Highlight';