<?php

$viewdefs['base']['filter']['operators']['HighLightfield'] = array(
    '$in' => 'LBL_OPERATOR_CONTAINS',
    '$not_in' => 'LBL_OPERATOR_NOT_CONTAINS',
    '$empty' => 'LBL_OPERATOR_EMPTY',
    '$not_empty' => 'LBL_OPERATOR_NOT_EMPTY',
);
